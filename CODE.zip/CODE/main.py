import sys

from PyQt6.QtCore import Qt, pyqtSignal
from PyQt6.QtWidgets import QApplication, QMainWindow, QWidget, QLabel, QLineEdit, QPushButton, QVBoxLayout, QTableWidget, QTableWidgetItem, QDialog, QFormLayout, QMessageBox, QVBoxLayout, QLineEdit, QSizePolicy, QMenu, QDialogButtonBox
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure

from database import Database  # Импортируем класс Database из database.py


class LoginWindow(QMainWindow):
    def __init__(self, parent=None):
        super().__init__(parent)

        self.setWindowTitle("Авторизация")
        self.setFixedSize(300, 210)

        self.login_label = QLabel("Логин:")
        self.password_label = QLabel("Пароль:")

        self.login_input = QLineEdit()
        # Set placeholder text for login input
        self.login_input.setPlaceholderText(
            "Введите логин (минимум 6 символов)")

        self.password_input = QLineEdit()
        # Set the echo mode for password input
        self.password_input.setPlaceholderText(
            "Введите пароль (минимум 8 символов)")
        self.password_input.setEchoMode(QLineEdit.EchoMode.Password)

        self.login_button = QPushButton("Войти")
        self.register_button = QPushButton("Зарегистрироваться")

        layout = QVBoxLayout()
        layout.addWidget(self.login_label)
        layout.addWidget(self.login_input)
        layout.addWidget(self.password_label)
        layout.addWidget(self.password_input)
        layout.addSpacing(20)
        layout.addWidget(self.login_button)
        layout.addWidget(self.register_button)

        widget = QWidget()
        widget.setLayout(layout)
        self.setCentralWidget(widget)

        self.login_button.clicked.connect(self.login)
        self.register_button.clicked.connect(self.register)

        self.database = Database()

    def login(self):
        username = self.login_input.text()
        password = self.password_input.text()

        user = self.database.verify_user(username, password)

        if user:
            if username == "worker" and password == "password":
                self.worker_window = WorkerWindow(parent=self, user=user)
                self.worker_window.show()
            else:
                self.main_window = MainWindow(parent=self, user=user)
                self.main_window.show()
            self.hide()
        else:
            QMessageBox.critical(
                self, 'Ошибка', 'Неправильно введен логин или пароль')

    def register(self):
        username = self.login_input.text().strip()
        password = self.password_input.text().strip()

        if not (6 <= len(username) <= 20):
            QMessageBox.warning(
                self, 'Ошибка', "Логин должен быть от 6 до 20 символов.")
            return

        if not (8 <= len(password) <= 25):
            QMessageBox.warning(
                self, 'Ошибка', "Пароль должен быть от 8 до 25 символов.")
            return

        if username == password:
            QMessageBox.warning(
                self, 'Ошибка', "Логин и пароль не могут совпадать.")
            return

        existing_user = self.database.verify_user(username, password)
        if existing_user:
            QMessageBox.warning(
                self, 'Ошибка', "Пользователь с такими данными уже существует.")
            return

        self.database.register_user(username, password)
        QMessageBox.information(self, 'Регистрация',
                                "Регистрация прошла успешно!")


class WorkerWindow(QMainWindow):
    new_message = pyqtSignal(str, str, str)

    def __init__(self, parent=None, user=None):
        super().__init__(parent)

        self.setWindowTitle("Окно администратора")
        self.setFixedSize(735, 480)

        self.database = Database()
        self.table = QTableWidget()
        self.update_table()

        self.address_input = QLineEdit()
        self.type_input = QLineEdit()
        self.area_input = QLineEdit()
        self.floors_input = QLineEdit()
        self.rooms_input = QLineEdit()
        self.cost_input = QLineEdit()

        self.table.setColumnHidden(0, True)  # скрывает колонку id
        self.table.setColumnWidth(1, 100)  # "Адрес"
        self.table.setColumnWidth(2, 100)  # "Тип"
        self.table.setColumnWidth(3, 100)  # "Площадь"
        self.table.setColumnWidth(4, 150)  # "Количество этажей"
        self.table.setColumnWidth(5, 150)  # "Количество комнат"
        self.table.setColumnWidth(6, 100)  # "Цена"

        self.add_button = QPushButton("Добавить информацию о недвижимости")
        self.add_button.clicked.connect(self.add_property)

        self.edit_button = QPushButton("Изменить информацию о недвижимости")
        self.edit_button.clicked.connect(self.open_edit_property)

        self.delete_button = QPushButton("Удалить информацию о недвижимости")
        self.delete_button.clicked.connect(self.delete_property)

        self.plot_button = QPushButton("Построить диаграмму")
        self.plot_button.clicked.connect(self.plot_graph)

        self.show_message_button = QPushButton("Показать сообщения")
        self.show_message_button.clicked.connect(self.show_messages)

        layout = QVBoxLayout()
        layout.addWidget(self.add_button)
        layout.addWidget(self.edit_button)
        layout.addWidget(self.delete_button)
        layout.addWidget(self.plot_button)
        layout.addWidget(self.table)

        widget = QWidget()
        widget.setLayout(layout)
        self.setCentralWidget(widget)

        self.logout_button = QPushButton("Выйти")
        self.logout_button.clicked.connect(self.logout)

        self.logout_button.setStyleSheet(
            "QPushButton { background-color: #ff6347; color: white; border: none; padding: 5px 10px; }"
            "QPushButton:hover { background-color: #e52b50; }")

        self.show_message_button.setStyleSheet(
            "QPushButton { background-color: #ff6347; color: white; border: none; padding: 5px 10px; }"
            "QPushButton:hover { background-color: #e52b50; }")

        layout.addWidget(self.show_message_button)
        layout.addWidget(self.logout_button)

        self.graph_window = None

    def logout(self):
        self.close()
        self.parent().show()

    def add_property(self):
        add_property_window = AddPropertyWindow(
            parent=self, database=self.database)
        if add_property_window.exec() == QDialog.DialogCode.Accepted:
            self.update_table()

    def open_add_property(self):
        self.add_property()

    def update_table(self):
        properties = self.database.get_properties()

        self.table.setRowCount(len(properties))
        self.table.setColumnCount(7)
        self.table.setHorizontalHeaderLabels(
            ["id", "Адрес", "Тип", "Площадь", "Количество этажей", "Количество комнат", "Цена"])

        for i, property in enumerate(properties):
            self.table.setColumnHidden(0, True)  # скрывает колонку id
            self.table.setItem(i, 0, QTableWidgetItem(str(property[0])))  # id
            self.table.setItem(i, 1, QTableWidgetItem(property[1]))  # address
            self.table.setItem(i, 2, QTableWidgetItem(property[2]))  # type
            self.table.setItem(i, 3, QTableWidgetItem(
                str(property[3])))  # area
            self.table.setItem(i, 4, QTableWidgetItem(
                str(property[4])))  # floors
            self.table.setItem(i, 5, QTableWidgetItem(
                str(property[5])))  # rooms
            self.table.setItem(i, 6, QTableWidgetItem(
                str(property[6])))  # cost

    def plot_graph(self):
        properties = self.database.get_properties()

        area_values = [property[3] for property in properties]
        cost_values = [property[6] for property in properties]

        if not self.graph_window:
            self.graph_window = GraphWindow(area_values, cost_values)
            self.graph_window.closing.connect(
                self.graph_window_closing)
            self.graph_window.show()
            self.graph_window.exec()
        else:
            self.graph_window.plot(area_values, cost_values)

    def show_messages(self):
        message_window = MessageWindow(parent=self, database=self.database)
        message_window.exec()

    def graph_window_closing(self):
        self.graph_window = None
        self.setEnabled(True)

    def open_edit_property(self):
        row = self.table.currentRow()
        if row == -1:
            QMessageBox.warning(
                self, "Предупреждение", "Выберите свойство для изменения")
            return
        id = int(self.table.item(row, 0).text())
        edit_property_window = EditPropertyWindow(
            parent=self, database=self.database, id=id)
        if edit_property_window.exec() == QDialog.DialogCode.Accepted:
            self.update_table()

    def delete_property(self):
        row = self.table.currentRow()
        if row == -1:
            QMessageBox.warning(
                self, "Предупреждение", "Выберите строку для удаления")
            return

        id = int(self.table.item(row, 0).text())
        reply = QMessageBox.question(self, 'Удалить', 'Вы уверены?')
        if reply == QMessageBox.StandardButton.Yes:
            self.database.delete_property(id)
            self.update_table()


class GraphWindow(QDialog):
    closing = pyqtSignal()

    def __init__(self, area_values, cost_values, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Диаграмма рассеивания")
        self.setModal(True)

        self.fig = Figure()
        self.canvas = FigureCanvas(self.fig)

        layout = QVBoxLayout()
        layout.addWidget(self.canvas)

        self.setLayout(layout)
        self.plot(area_values, cost_values)

    def plot(self, x, y):
        ax = self.fig.add_subplot(111)
        ax.scatter(x, y)
        ax.set_xlabel("Площадь")
        ax.set_ylabel("Цена")
        ax.set_title("Зависимость площади от стоимости")
        self.canvas.draw()

    def closeEvent(self, event):
        self.closing.emit()
        self.hide()
        event.ignore()


class EditPropertyWindow(QDialog):
    def __init__(self, parent=None, database=None, id=None):
        super().__init__(parent)
        self.setWindowTitle("Изменить информацию о недвижимости")
        self.setModal(True)

        self.database = database
        self.id = id

        self.property_data = database.get_properties(id=id)

        self.address_input = QLineEdit(self.property_data[1])
        self.type_input = QLineEdit(self.property_data[2])
        self.area_input = QLineEdit(str(self.property_data[3]))
        self.floors_input = QLineEdit(str(self.property_data[4]))
        self.rooms_input = QLineEdit(str(self.property_data[5]))
        self.cost_input = QLineEdit(str(self.property_data[6]))

        self.save_button = QPushButton("Сохранить")
        self.save_button.clicked.connect(self.edit_property)

        layout = QFormLayout()
        layout.addRow("Адрес:", self.address_input)
        layout.addRow("Тип:", self.type_input)
        layout.addRow("Площадь:", self.area_input)
        layout.addRow("Количество этажей:", self.floors_input)
        layout.addRow("Количество комнат:", self.rooms_input)
        layout.addRow("Цена:", self.cost_input)
        layout.addRow(self.save_button)

        self.setLayout(layout)

    def edit_property(self):
        address = self.address_input.text()
        property_type = self.type_input.text()
        area_text = self.area_input.text()
        floors_text = self.floors_input.text()
        rooms_text = self.rooms_input.text()
        cost_text = self.cost_input.text()

        if not address or not property_type or not area_text or not floors_text or not rooms_text or not cost_text:
            QMessageBox.critical(
                self, "Ошибка", "Пожалуйста, заполните все поля")
            return

        try:
            area = float(area_text)
            floors = int(floors_text)
            rooms = int(rooms_text)
            cost = float(cost_text)
        except ValueError:
            QMessageBox.critical(
                self, "Ошибка", "Пожалуйста, введите корректные значения")
            return

        self.database.update_property(
            self.id, address, property_type, area, floors, rooms, cost)
        self.accept()


class SendMessageWindow(QDialog):
    def __init__(self, parent=None, database=None):
        super().__init__(parent)
        self.setWindowTitle("Отправить сообщение")
        self.setModal(True)

        self.database = database

        self.sender_name_input = QLineEdit()
        self.sender_surname_input = QLineEdit()
        self.mobile_input = QLineEdit()
        self.subject_input = QLineEdit()
        self.message_input = QLineEdit()

        self.send_button = QPushButton("Отправить")
        self.send_button.clicked.connect(self.send_message)

        layout = QFormLayout()
        layout.addRow("Имя:", self.sender_name_input)
        layout.addRow("Фамилия:", self.sender_surname_input)
        layout.addRow("Мобильный телефон:",
                      self.mobile_input)
        layout.addRow("Тема сообщения:", self.subject_input)
        layout.addRow("Сообщение:", self.message_input)
        layout.addRow(self.send_button)

        self.setLayout(layout)

    def send_message(self):
        name = self.sender_name_input.text()
        surname = self.sender_surname_input.text()
        mobile = self.mobile_input.text()
        subject = self.subject_input.text()
        message = self.message_input.text()

        if not subject or not message or not mobile:
            QMessageBox.critical(
                self, "Ошибка", "Пожалуйста, заполните все поля")
            return

        self.database.add_message(name, surname, mobile, subject, message)
        self.accept()


class AddPropertyWindow(QDialog):
    def __init__(self, parent=None, database=None):
        super().__init__(parent)
        self.setWindowTitle("Добавить информацию о недвижимости")
        self.setModal(True)

        self.database = database

        self.address_input = QLineEdit()
        self.type_input = QLineEdit()
        self.area_input = QLineEdit()
        self.floors_input = QLineEdit()
        self.rooms_input = QLineEdit()
        self.cost_input = QLineEdit()

        self.add_button = QPushButton("Добавить")
        self.add_button.clicked.connect(self.add_property)

        layout = QFormLayout()
        layout.addRow("Адрес:", self.address_input)
        layout.addRow("Тип:", self.type_input)
        layout.addRow("Площадь:", self.area_input)
        layout.addRow("Количество этажей:", self.floors_input)
        layout.addRow("Количество комнат:", self.rooms_input)
        layout.addRow("Цена:", self.cost_input)
        layout.addRow(self.add_button)

        self.setLayout(layout)

    def add_property(self):
        address = self.address_input.text()
        property_type = self.type_input.text()
        area_text = self.area_input.text()
        floors_text = self.floors_input.text()
        rooms_text = self.rooms_input.text()
        cost_text = self.cost_input.text()

        if not address or not property_type or not area_text or not floors_text or not rooms_text or not cost_text:
            QMessageBox.critical(
                self, "Ошибка", "Пожалуйста, заполните все поля")
            return

        try:
            area = float(area_text)
            floors = int(floors_text)
            rooms = int(rooms_text)
            cost = float(cost_text)
        except ValueError:
            QMessageBox.critical(
                self, "Ошибка", "Пожалуйста, введите корректные значения")
            return

        self.database.add_property(
            address, property_type, area, floors, rooms, cost)
        self.accept()


class MessageWindow(QDialog):
    def __init__(self, parent=None, database=None):
        super().__init__(parent)
        self.setWindowTitle("Сообщения")
        self.setModal(True)
        self.setFixedSize(540, 300)

        self.database = database
        self.message_data = database.get_messages()

        self.message_list = QTableWidget()
        self.message_list.setRowCount(len(self.message_data))
        self.message_list.setColumnCount(5)
        self.message_list.setHorizontalHeaderLabels(
            ["Имя", "Фамилия", "Мобильный телефон", "Тема сообщения", "Сообщение"])

        for i, message in enumerate(self.message_data):
            self.message_list.setItem(i, 0, QTableWidgetItem(message[1]))
            self.message_list.setItem(i, 1, QTableWidgetItem(message[2]))
            self.message_list.setItem(i, 2, QTableWidgetItem(message[3]))
            self.message_list.setItem(i, 3, QTableWidgetItem(message[4]))
            self.message_list.setItem(i, 4, QTableWidgetItem(message[5]))

        layout = QVBoxLayout()
        layout.addWidget(self.message_list)
        self.setLayout(layout)


class MainWindow(QMainWindow):
    def __init__(self, parent=None, user=None):
        super().__init__(parent)

        self.setWindowTitle("Окно клиента")
        self.setFixedSize(735, 300)

        self.database = Database()
        properties = self.database.get_properties()

        self.table = QTableWidget()
        self.table.setRowCount(len(properties))
        self.table.setColumnCount(6)
        self.table.setHorizontalHeaderLabels(
            ["Адрес", "Тип", "Площадь", "Количество этажей", "Количество комнат", "Цена"])

        for i, property in enumerate(properties):
            self.table.setItem(i, 0, QTableWidgetItem(property[1]))
            self.table.setItem(i, 1, QTableWidgetItem(property[2]))
            self.table.setItem(i, 2, QTableWidgetItem(str(property[3])))
            self.table.setItem(i, 3, QTableWidgetItem(str(property[4])))
            self.table.setItem(i, 4, QTableWidgetItem(str(property[5])))
            self.table.setItem(i, 5, QTableWidgetItem(str(property[6])))

        self.table.setColumnWidth(1, 100)  # "Адрес"
        self.table.setColumnWidth(2, 100)  # "Тип"
        self.table.setColumnWidth(3, 150)  # "Площадь"
        self.table.setColumnWidth(4, 150)  # "Количество этажей"
        self.table.setColumnWidth(5, 100)  # "Количество комнат"
        self.table.setColumnWidth(6, 100)  # "Цена"

        layout = QVBoxLayout()
        layout.addWidget(self.table)

        widget = QWidget()
        widget.setLayout(layout)
        self.setCentralWidget(widget)

        self.logout_button = QPushButton("Выйти")
        self.logout_button.clicked.connect(self.logout)

        self.username = user[1]

        self.send_message_button = QPushButton("Написать сообщение")
        self.send_message_button.clicked.connect(self.send_message)

        layout.addWidget(self.send_message_button)

        self.logout_button.setStyleSheet(
            "QPushButton { background-color: #66CCFF; color: black; border: none; padding: 5px 10px; }"
            "QPushButton:hover { background-color: #66CCFF; }"
        )

        self.send_message_button.setStyleSheet(
            "QPushButton { background-color: #66CCFF; color: black; border: none; padding: 5px 10px; }"
            "QPushButton:hover { background-color: #66CCFF; }"
        )

        layout.addWidget(self.logout_button)

    def logout(self):
        self.close()
        self.parent().show()

    def send_message(self):
        send_message_window = SendMessageWindow(
            parent=self, database=self.database)
        send_message_window.exec()


if __name__ == '__main__':
    app = QApplication(sys.argv)

    login_window = LoginWindow()
    login_window.show()

    sys.exit(app.exec())
